<?php
namespace App\Controllers\Catalogos;

use App\Controllers\BaseController;
use App\Models\Catalogos\FechaEspecialModel;

class FechaEspecialController extends BaseController {

  public function __construct() {
    $this->model = new FechaEspecialModel();
  }

	public function index() {
    $data['title'] = 'Fechas Especiales';
    return view('Catalogos/fechas-especiales', $data);
  }

  public function guardarFechaEspecial() {
    // Validar Datos.
    if (!$this->validate([
      'concepto'  => 'required', 'inicio'    => 'required', 'fin'       => 'required'
    ])):
      $res = [
        'error'         => true,
        'code_error'    => 400,
        'error_title'   => 'Invalid Form Validation',
        'error_message' => null,
        'response'      => $this->validator->getErrors()
      ];
      return $this->response->setStatusCode(400)->setJSON($res);
    endif;
    // Obtener Datos
    $concepto = trim(strip_tags($this->request->getPost('concepto')));
    $inicio = trim($this->request->getPost('inicio'));
    $inicio = explode('/', $inicio);
    $fin = trim($this->request->getPost('fin'));
    $fin = explode('/', $fin);

    $data = [
      'especialConcepto'  => $concepto, 
      'especialDiaInicio' => $inicio[0], 
      'especialMesInicio' => $inicio[1], 
      'especialDiaFin'    => $fin[0], 
      'especialMesFin'    => $fin[1]
    ];
    try {
      $this->model->guardar($data);
    } catch (\Throwable $th) {
      //throw $th;
      $res = [
        'error'         => true,
        'code_error'    => 500,
        'error_title'   => 'Internal Server Error',
        'error_message' => 'Ha ocurrido un problema al guardar la información',
        'response'      => null
      ];
      return $this->response->setStatusCode(500)->setJSON($res);
    }
    return $this->response->setStatusCode(201);
  }

  public function eliminarFechaEspecial(int $id) {
    try {
      $this->model->eliminar($id);
    } catch (\Throwable $th) {
      //throw $th;
      $res = [
        'error'         => true,
        'code_error'    => 404,
        'error_title'   => 'Info Not Found',
        'error_message' => 'EL registro no existe',
        'response'      => $th
      ];
      return $this->response->setStatusCode(404)->setJSON($res);
    }
    return $this->response->setStatusCode(200);
  }

  public function obtenerPorId(int $id) {
    $data = $this->model->obtenerPorId($id);
    if (is_null($data)):
      $res = [
        'error'         => true,
        'code_error'    => 404,
        'error_title'   => 'Info Not Found',
        'error_message' => 'EL registro no existe'
      ];
      return $this->response->setStatusCode(404)->setJSON($res);
    endif;
    $res = [
      'error'         => false,
      'code_error'    => null,
      'error_title'   => '',
      'error_message' => '',
      'response'      => $data
    ];
    return $this->response->setStatusCode(200)->setJSON($res);
  }

  public function actualizarFechaEspecial(int $id) {
    // Validar Datos
    if (!$this->validate([
      'concepto' => 'required', 'inicio' => 'required', 'fin' => 'required'
    ])):
      $res = [
        'error'         => true,
        'code_error'    => 400,
        'error_title'   => 'Invalid Form Validation',
        'error_message' => null,
        'response'      => $this->validator->getErrors()
      ];
      return $this->response->setStatusCode(400)->setJSON($res);
    endif;
    // Obtener Datos
    $concepto = trim(strip_tags(strtoupper($this->request->getJsonVar('concepto'))));
    $inicio = trim($this->request->getJsonVar('inicio', true));
    $inicio = explode('/', $inicio);
    $fin = trim($this->request->getJsonVar('fin', true));
    $fin = explode('/', $fin);

    $data = [
      'especialConcepto'  => $concepto, 
      'especialDiaInicio' => $inicio[0], 
      'especialMesInicio' => $inicio[1], 
      'especialDiaFin'    => $fin[0], 
      'especialMesFin'    => $fin[1]
    ];
    
    try {
      $this->model->modificar($id, $data);
    } catch (\Throwable $th) {
      //throw $th;
      $res = [
        'error'         => true,
        'code_error'    => 500,
        'error_title'   => 'Internal Server Error',
        'error_message' => 'Ha ocurrido un problema al guardar la información',
        'response'      => null
      ];
      return $this->response->setStatusCode(500)->setJSON($res);
    }
    $respuesta = [ "messaje" => "EL registro a sido actualizado exitosamente." ];

    $res = [
      'error'         => false,
      'code_error'    => 0,
      'error_title'   => '',
      'error_message' => '',
      'response'      => $respuesta
    ];
    return $this->response->setStatusCode(201)->setJSON($res);
  }

  public function obtenerTabla() {
    $data = $this->model->obtenerTodo();
    $tabla = '';
    foreach($data as $item):
      $accion = '<div class=\"custom-control custom-radio\">';
      $accion .= '<input type=\"radio\" id=\"row-'.$item->especialId.'\" name=\"id\" class=\"custom-control-input\" value=\"'.$item->especialId.'\">';
      $accion .= '<label class=\"custom-control-label\" for=\"row-'.$item->especialId.'\"> Seleccionar </label> </div>';
      $inicio = '';
      if ($item->especialDiaInicio < 10):
        $inicio .= '0'. $item->especialDiaInicio;
      else:
        $inicio .= $item->especialDiaInicio;
      endif;

      if ($item->especialMesInicio < 10):
        $inicio .= '/0'. $item->especialMesInicio;
      else :
        $inicio .= '/'. $item->especialMesInicio;
      endif;

      $fin = '';
      
      if ($item->especialDiaFin < 10):
        $fin .= '0'. $item->especialDiaFin;
      else:
        $fin .= $item->especialDiaFin;
      endif;

      if ($item->especialMesFin < 10):
        $fin .= '/0'. $item->especialMesFin;
      else :
        $fin .= '/'. $item->especialMesFin;
      endif;

      $tabla .= '{
        "concepto" : "'.$item->especialConcepto.'",
        "inicio"   : "'.$inicio.'",
        "fin"      : "'.$fin.'",
        "acciones" : "'.$accion.'"
      },';
    endforeach;
    $tabla = substr($tabla, 0, strlen($tabla) - 1);
    $result = '{"data" : ['. $tabla .']}';
    return $this->response->setStatusCode(200)->setBody($result);
  }
}